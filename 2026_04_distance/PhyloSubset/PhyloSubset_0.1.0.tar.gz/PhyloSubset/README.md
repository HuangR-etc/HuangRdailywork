# PhyloSubset

**PhyloSubset selects phylogenetically dispersed or clustered species subsets from a user-defined candidate pool and evaluates their distance-based dispersion and covariance-based dependence.**

Given a phylogenetic tree, a candidate species pool, and a target subset size, PhyloSubset automatically selects dispersed or clustered subsets, computes distance metrics (MinPD, MeanPD, MeanNND, MaxPD), generates random baselines, calculates empirical p-values, and evaluates phylogenetic dependence diagnostics (MeanOffCor, MaxOffCor, MeanESS) under Brownian motion, Pagel's lambda, and Ornstein-Uhlenbeck covariance models.

## Installation

```r
# Install from source
install.packages("path/to/PhyloSubset", repos = NULL, type = "source")
```

## Quick Start

```r
library(PhyloSubset)
library(ape)

# Create a random tree for demonstration
set.seed(42)
tree <- rtree(30)
candidates <- tree$tip.label

# One-step analysis
res <- phylo_subset(
  tree = tree,
  candidates = candidates,
  size = 8,
  type = "dispersed",
  n_random = 500,
  cov_model = "BM",
  seed = 123
)

# View results
summary(res)
plot(res)                    # Tree with selected species highlighted
plot(res, metric = "MeanNND") # Random baseline comparison
```

## Core Functions

| Category | Function | Purpose |
|----------|----------|---------|
| **Main entry** | `phylo_subset()` | One-step subset selection, random baseline, and dependence diagnostics |
| **Selection** | `select_dispersed()` | Build phylogenetically dispersed subset (greedy + swap refinement) |
| **Selection** | `select_clustered()` | Build high-dependence clustered reference subset |
| **Distance** | `distance_metrics()` | Compute MinPD, MaxPD, MeanPD, MeanNND |
| **Random baseline** | `random_baseline()` | Generate random subset metric distributions |
| **Significance** | `empirical_p_value()` | Calculate corrected empirical p-value |
| **Comparison** | `compare_to_random()` | Compare observed subset to random baseline |
| **Covariance** | `phylo_covariance()` | Generate BM, lambda, OU covariance matrix |
| **Correlation** | `cov_to_cor()` | Convert covariance to correlation |
| **Dependence** | `dependence_metrics()` | Compute MeanOffCor, MaxOffCor, MeanESS |
| **ESS** | `mean_ess()` | Calculate mean-based effective sample size |
| **Visualization** | `plot_random_baseline()` | Plot random distribution with observed value |
| **Visualization** | `plot_subset_tree()` | Highlight selected species on tree |
| **Sensitivity** | `covariance_sensitivity()` | Compare lambda and OU assumptions |

## Advanced Usage

```r
# Step-by-step analysis
D <- patristic_matrix(tree, candidates)

# Select dispersed subset
disp <- select_dispersed(
  dist_mat = D,
  candidates = candidates,
  size = 8,
  refine = TRUE,
  seed = 42
)

# Compute observed metrics
obs <- distance_metrics(D, disp$selected)

# Generate random baseline
rand <- random_baseline(
  dist_mat = D,
  candidates = candidates,
  size = 8,
  n = 1000
)

# Compare to random
compare_to_random(obs, rand, type = "dispersed")

# Dependence diagnostics
V <- phylo_covariance(tree, candidates, model = "BM")
R <- cov_to_cor(V[disp$selected, disp$selected])
dependence_metrics(R)
```

## Package Structure

```
R/
  input_checks.R       # check_phylo_input, match_species, prune_to_candidates, patristic_matrix
  distances.R          # distance_metrics, min_pd, max_pd, mean_pd, mean_nnd
  select_dispersed.R   # select_dispersed, greedy_dispersed, swap_refine
  select_clustered.R   # select_clustered, generate_seed_neighborhoods
  random_baseline.R    # random_subsets, random_baseline, empirical_p_value, compare_to_random
  covariance.R         # phylo_covariance, cov_to_cor, dependence_metrics, mean_ess
  plotting.R           # plot_subset_tree, plot_random_baseline, plot_dependence_sensitivity
  sensitivity.R        # subset_size_sensitivity, candidate_pool_sensitivity, covariance_sensitivity
  phylo_subset.R       # phylo_subset, S3 methods (print, summary, plot, as.data.frame)
```

## License

GPL-3

#' Plotting functions for PhyloSubset
#'
#' Visualization functions for subset trees, random baseline comparisons,
#' and covariance sensitivity analyses.
#'
#' @name plotting
NULL

#' @rdname plotting
#' @export
#' @title Plot a tree with highlighted subset species
#' @description Plots a phylogenetic tree with the selected subset species
#'   highlighted in color.
#' @param tree A phylogenetic tree of class \code{phylo}.
#' @param subset Character vector of species names to highlight.
#' @param candidates Optional character vector of candidate species. If
#'   provided, non-candidate tips are shown in gray.
#' @param layout Tree layout: \code{"rectangular"}, \code{"circular"}, or
#'   \code{"fan"}.
#' @param tip_labels If \code{TRUE}, show tip labels.
#' @param highlight_col Color for highlighted tips (default: "red").
#' @param main Title for the plot.
#' @param ... Additional arguments passed to \code{plot.phylo}.
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(20)
#' subset <- sample(tree$tip.label, 5)
#' plot_subset_tree(tree, subset)
#' }
plot_subset_tree <- function(tree, subset, candidates = NULL,
                             layout = c("rectangular", "circular", "fan"),
                             tip_labels = TRUE, highlight_col = "red",
                             main = "", ...) {
  layout <- match.arg(layout)

  tip_colors <- rep("black", ape::Ntip(tree))
  names(tip_colors) <- tree$tip.label

  if (!is.null(candidates)) {
    tip_colors[!tree$tip.label %in% candidates] <- "gray80"
  }

  tip_colors[tree$tip.label %in% subset] <- highlight_col

  tip_cex <- rep(0.7, ape::Ntip(tree))
  tip_cex[tree$tip.label %in% subset] <- 0.9

  ape::plot.phylo(tree, type = layout, tip.color = tip_colors,
                  cex = if (tip_labels) tip_cex else 0,
                  main = main, ...)

  if (length(subset) > 0) {
    graphics::legend("topleft",
           legend = paste("Selected (n =", length(subset), ")"),
           text.col = highlight_col, bty = "n")
  }
}

#' @rdname plotting
#' @export
#' @title Plot random baseline distribution with observed value
#' @description Plots a histogram of random baseline values for a given metric
#'   with a vertical line showing the observed value.
#' @param random_metrics A data frame of random baseline metrics (as returned
#'   by \code{random_baseline}).
#' @param observed A named list or vector containing the observed metric value.
#' @param metric The metric to plot: \code{"MinPD"}, \code{"MeanPD"},
#'   \code{"MeanNND"}, or \code{"MaxPD"}.
#' @param type Subset type: \code{"dispersed"} or \code{"clustered"}. Used
#'   for annotation.
#' @param ... Additional arguments passed to \code{hist}.
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(20)
#' D <- ape::cophenetic.phylo(tree)
#' rand <- random_baseline(D, tree$tip.label, size = 5, n = 100)
#' obs <- distance_metrics(D, sample(tree$tip.label, 5))
#' plot_random_baseline(rand, obs, metric = "MeanPD")
#' }
plot_random_baseline <- function(random_metrics, observed, metric,
                                 type = c("dispersed", "clustered"), ...) {
  type <- match.arg(type)

  if (!metric %in% names(random_metrics)) {
    stop("metric not found in random_metrics")
  }

  null_vals <- random_metrics[[metric]]
  obs_val <- observed[[metric]]

  graphics::hist(null_vals, main = paste(metric, "- Random Baseline"),
       xlab = metric, col = "lightgray", border = "white", ...)
  graphics::abline(v = obs_val, col = "red", lwd = 2, lty = 2)

  p_val <- if (type == "dispersed") {
    empirical_p_value(obs_val, null_vals, "greater")
  } else {
    empirical_p_value(obs_val, null_vals, "less")
  }

  graphics::legend("topright",
         legend = paste0("Observed (p = ", format(p_val, digits = 3), ")"),
         text.col = "red", bty = "n")
}

#' @rdname plotting
#' @export
#' @title Plot covariance sensitivity analysis
#' @description Plots the results of a covariance sensitivity analysis,
#'   showing how dependence metrics change with lambda or OU half-life ratio.
#' @param sensitivity_result A data frame from \code{covariance_sensitivity}.
#' @param x Variable for x-axis: \code{"lambda"} or \code{"half_life_ratio"}.
#' @param y Variable for y-axis: \code{"MeanESS"}, \code{"MeanOffCor"}, or
#'   \code{"MaxOffCor"}.
#' @param ... Additional arguments passed to \code{plot}.
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(10)
#' subset <- tree$tip.label[1:4]
#' sens <- covariance_sensitivity(tree, subset)
#' plot_dependence_sensitivity(sens, x = "lambda", y = "MeanESS")
#' }
plot_dependence_sensitivity <- function(sensitivity_result,
                                        x = c("lambda", "half_life_ratio"),
                                        y = c("MeanESS", "MeanOffCor", "MaxOffCor"),
                                        ...) {
  x <- match.arg(x)
  y <- match.arg(y)

  if (!x %in% names(sensitivity_result)) {
    stop("x variable not found in sensitivity_result")
  }
  if (!y %in% names(sensitivity_result)) {
    stop("y variable not found in sensitivity_result")
  }

  x_vals <- sensitivity_result[[x]]
  y_vals <- sensitivity_result[[y]]

  graphics::plot(x_vals, y_vals, type = "b", pch = 19,
       xlab = x, ylab = y,
       main = paste(y, "vs", x), ...)
  graphics::lines(x_vals, y_vals, col = "blue")
}

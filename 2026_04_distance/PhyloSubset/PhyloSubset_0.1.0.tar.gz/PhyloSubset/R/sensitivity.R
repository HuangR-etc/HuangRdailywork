#' Sensitivity analysis functions
#'
#' Functions for exploring how subset metrics and dependence diagnostics
#' change with subset size, candidate pool size, and covariance model
#' parameters.
#'
#' @name sensitivity
NULL

#' @rdname sensitivity
#' @export
#' @title Subset size sensitivity analysis
#' @description Runs the full analysis pipeline across multiple subset sizes
#'   for a fixed tree and candidate pool.
#' @param tree A phylogenetic tree of class \code{phylo}.
#' @param candidates Character vector of candidate species names.
#' @param sizes Numeric vector of subset sizes to test.
#' @param type Subset type: \code{"dispersed"} or \code{"clustered"}.
#' @param n_random Number of random subsets for baseline (default: 1000).
#' @param seed Optional random seed.
#' @return A data frame with columns: size, MinPD, MeanPD, MeanNND, MaxPD,
#'   MeanOffCor, MaxOffCor, MeanESS, p_value (for the primary metric).
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(20)
#' candidates <- tree$tip.label
#' sens <- subset_size_sensitivity(tree, candidates, sizes = c(3, 5, 7),
#'                                 n_random = 50)
#' sens
#' }
subset_size_sensitivity <- function(tree, candidates, sizes,
                                    type = c("dispersed", "clustered"),
                                    n_random = 1000, seed = NULL) {
  type <- match.arg(type)

  if (!is.null(seed)) set.seed(seed)

  dist_mat <- patristic_matrix(tree, candidates)
  V_bm <- phylo_covariance(tree, candidates, model = "BM")

  results <- do.call(rbind, lapply(sizes, function(s) {
    if (type == "dispersed") {
      sel <- select_dispersed(
        dist_mat = dist_mat, candidates = candidates,
        size = s, refine = TRUE, seed = seed
      )
    } else {
      sel <- select_clustered(
        dist_mat = dist_mat, candidates = candidates, size = s
      )
    }

    obs_metrics <- sel$metrics

    # Random baseline
    rand_metrics <- random_baseline(
      dist_mat, candidates, size = s, n = n_random
    )

    # P-value for primary metric
    primary <- if (type == "dispersed") "MinPD" else "MeanPD"
    p_val <- if (type == "dispersed") {
      empirical_p_value(obs_metrics[[primary]], rand_metrics[[primary]], "greater")
    } else {
      empirical_p_value(obs_metrics[[primary]], rand_metrics[[primary]], "less")
    }

    # Dependence
    R_sub <- cov_to_cor(V_bm[sel$selected, sel$selected, drop = FALSE])
    dep <- dependence_metrics(R_sub)

    data.frame(
      size = s,
      MinPD = obs_metrics$MinPD,
      MeanPD = obs_metrics$MeanPD,
      MeanNND = obs_metrics$MeanNND,
      MaxPD = obs_metrics$MaxPD,
      MeanOffCor = dep$MeanOffCor,
      MaxOffCor = dep$MaxOffCor,
      MeanESS = dep$MeanESS,
      p_value = p_val,
      stringsAsFactors = FALSE
    )
  }))

  results
}

#' @rdname sensitivity
#' @export
#' @title Candidate pool sensitivity analysis
#' @description Runs the analysis across multiple candidate pools (e.g.,
#'   nested subsets of a larger pool) to assess sensitivity to pool size.
#' @param tree A phylogenetic tree of class \code{phylo}.
#' @param candidate_pools A named list of candidate pools, each a character
#'   vector of species names.
#' @param sizes A named numeric vector of subset sizes, with names matching
#'   \code{candidate_pools}.
#' @param n_random Number of random subsets for baseline (default: 1000).
#' @param seed Optional random seed.
#' @return A data frame with columns: pool, N, size, MinPD, MeanPD, MeanNND,
#'   MaxPD, MeanOffCor, MaxOffCor, MeanESS, p_value.
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(30)
#' pools <- list(
#'   pool1 = tree$tip.label[1:10],
#'   pool2 = tree$tip.label[1:20]
#' )
#' sens <- candidate_pool_sensitivity(tree, pools,
#'                                    sizes = c(pool1 = 3, pool2 = 5),
#'                                    n_random = 50)
#' sens
#' }
candidate_pool_sensitivity <- function(tree, candidate_pools, sizes,
                                       n_random = 1000, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)

  results <- do.call(rbind, lapply(names(candidate_pools), function(pool_name) {
    candidates <- candidate_pools[[pool_name]]
    s <- sizes[pool_name]

    dist_mat <- patristic_matrix(tree, candidates)
    V_bm <- phylo_covariance(tree, candidates, model = "BM")

    # Dispersed
    disp <- select_dispersed(
      dist_mat = dist_mat, candidates = candidates,
      size = s, refine = TRUE, seed = seed
    )

    # Clustered
    clust <- select_clustered(
      dist_mat = dist_mat, candidates = candidates, size = s
    )

    # Random baseline
    rand_metrics <- random_baseline(
      dist_mat, candidates, size = s, n = n_random
    )

    # Dependence for dispersed
    R_disp <- cov_to_cor(V_bm[disp$selected, disp$selected, drop = FALSE])
    dep_disp <- dependence_metrics(R_disp)

    # P-value for dispersed MinPD
    p_val <- empirical_p_value(
      disp$metrics$MinPD, rand_metrics$MinPD, "greater"
    )

    data.frame(
      pool = pool_name,
      N = length(candidates),
      size = s,
      MinPD = disp$metrics$MinPD,
      MeanPD = disp$metrics$MeanPD,
      MeanNND = disp$metrics$MeanNND,
      MaxPD = disp$metrics$MaxPD,
      MeanOffCor = dep_disp$MeanOffCor,
      MaxOffCor = dep_disp$MaxOffCor,
      MeanESS = dep_disp$MeanESS,
      p_value = p_val,
      stringsAsFactors = FALSE
    )
  }))

  results
}

#' @rdname sensitivity
#' @export
#' @title Covariance model sensitivity analysis
#' @description Evaluates how dependence metrics (MeanOffCor, MaxOffCor,
#'   MeanESS) change under different covariance model assumptions for a
#'   given subset.
#' @param tree A phylogenetic tree of class \code{phylo}.
#' @param subset Character vector of species names in the subset.
#' @param models Covariance models to test: \code{"lambda"} and/or \code{"OU"}.
#' @param lambdas Numeric vector of lambda values (default: c(0, 0.1, 0.25,
#'   0.5, 0.75, 1)).
#' @param half_life_ratios Numeric vector of OU half-life ratios relative to
#'   tree height (default: c(0.05, 0.1, 0.25, 0.5, 1)).
#' @return A data frame with columns: cov_model, lambda, half_life_ratio,
#'   MeanOffCor, MaxOffCor, MeanESS.
#' @examples
#' \donttest{
#' library(ape)
#' tree <- rtree(10)
#' subset <- tree$tip.label[1:4]
#' sens <- covariance_sensitivity(tree, subset)
#' sens
#' }
covariance_sensitivity <- function(tree, subset,
                                   models = c("lambda", "OU"),
                                   lambdas = c(0, 0.1, 0.25, 0.5, 0.75, 1),
                                   half_life_ratios = c(0.05, 0.1, 0.25, 0.5, 1)) {
  tree_height <- max(ape::node.depth.edgelength(tree)[seq_len(ape::Ntip(tree))])

  results <- list()

  if ("lambda" %in% models) {
    for (lam in lambdas) {
      V <- phylo_covariance(tree, subset, model = "lambda", lambda = lam)
      R <- cov_to_cor(V)
      dep <- dependence_metrics(R)
      results[[length(results) + 1]] <- data.frame(
        cov_model = "lambda",
        lambda = lam,
        half_life_ratio = NA_real_,
        MeanOffCor = dep$MeanOffCor,
        MaxOffCor = dep$MaxOffCor,
        MeanESS = dep$MeanESS,
        stringsAsFactors = FALSE
      )
    }
  }

  if ("OU" %in% models) {
    for (hl_frac in half_life_ratios) {
      half_life <- hl_frac * tree_height
      V <- phylo_covariance(tree, subset, model = "OU", half_life = half_life)
      R <- cov_to_cor(V)
      dep <- dependence_metrics(R)
      results[[length(results) + 1]] <- data.frame(
        cov_model = "OU",
        lambda = NA_real_,
        half_life_ratio = hl_frac,
        MeanOffCor = dep$MeanOffCor,
        MaxOffCor = dep$MaxOffCor,
        MeanESS = dep$MeanESS,
        stringsAsFactors = FALSE
      )
    }
  }

  do.call(rbind, results)
}
